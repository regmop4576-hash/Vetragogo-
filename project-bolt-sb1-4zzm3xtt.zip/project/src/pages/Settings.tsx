import { useState, useEffect } from 'react';
import { ArrowLeft, Key, Cpu, Thermometer, Hash, Percent, MessageSquare, Shield } from 'lucide-react';
import { getSettings, saveSettings } from '../lib/db';
import type { AppSettings } from '../lib/types';
import { DEFAULT_SETTINGS, MODELS } from '../lib/types';

export default function Settings({ onBack }: { onBack: () => void }) {
  const [s, setS] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getSettings().then(setS);
  }, []);

  const update = (partial: Partial<AppSettings>) => {
    const next = { ...s, ...partial };
    setS(next);
    saveSettings(next).then(() => {
      setSaved(true);
      setTimeout(() => setSaved(false), 1500);
    });
  };

  return (
    <div className="min-h-screen bg-surface-0">
      <header className="sticky top-0 z-10 bg-surface-0/80 backdrop-blur border-b border-surface-2">
        <div className="max-w-2xl mx-auto flex items-center gap-3 px-4 h-14">
          <button onClick={onBack} className="btn-ghost flex items-center gap-2">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-lg font-semibold">Settings</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        <Card icon={<Key size={18} />} title="API Key">
          <input
            type="password"
            value={s.apiKey}
            onChange={e => update({ apiKey: e.target.value })}
            placeholder="sk-or-v1-..."
            className="input-field w-full"
          />
          <p className="text-xs text-gray-500 mt-1.5">
            Get your key at{' '}
            <a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer" className="text-blue-400 hover:underline">
              openrouter.ai/keys
            </a>
          </p>
        </Card>

        <Card icon={<Cpu size={18} />} title="Model">
          <select
            value={s.model}
            onChange={e => update({ model: e.target.value })}
            className="input-field w-full"
          >
            {MODELS.map(m => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </Card>

        <Card icon={<Thermometer size={18} />} title="Temperature">
          <div className="flex items-center gap-3">
            <input
              type="range" min={0} max={2} step={0.05}
              value={s.temperature}
              onChange={e => update({ temperature: parseFloat(e.target.value) })}
              className="flex-1 accent-blue-500"
            />
            <span className="text-sm text-gray-400 w-10 text-right">{s.temperature.toFixed(2)}</span>
          </div>
        </Card>

        <Card icon={<Hash size={18} />} title="Max Tokens">
          <div className="flex items-center gap-3">
            <input
              type="range" min={100} max={4096} step={64}
              value={s.maxTokens}
              onChange={e => update({ maxTokens: parseInt(e.target.value) })}
              className="flex-1 accent-blue-500"
            />
            <span className="text-sm text-gray-400 w-12 text-right">{s.maxTokens}</span>
          </div>
        </Card>

        <Card icon={<Percent size={18} />} title="Top-P">
          <div className="flex items-center gap-3">
            <input
              type="range" min={0} max={1} step={0.05}
              value={s.topP}
              onChange={e => update({ topP: parseFloat(e.target.value) })}
              className="flex-1 accent-blue-500"
            />
            <span className="text-sm text-gray-400 w-10 text-right">{s.topP.toFixed(2)}</span>
          </div>
        </Card>

        <Card icon={<MessageSquare size={18} />} title="Context Messages">
          <div className="flex items-center gap-3">
            <input
              type="range" min={5} max={50} step={1}
              value={s.contextLength}
              onChange={e => update({ contextLength: parseInt(e.target.value) })}
              className="flex-1 accent-blue-500"
            />
            <span className="text-sm text-gray-400 w-8 text-right">{s.contextLength}</span>
          </div>
          <p className="text-xs text-gray-500 mt-1.5">
            Number of recent messages to include in each API request
          </p>
        </Card>

        <Card icon={<Shield size={18} />} title="Jailbreak Prompt">
          <textarea
            value={s.jailbreakPrompt}
            onChange={e => update({ jailbreakPrompt: e.target.value })}
            placeholder="Optional system prompt appended to all requests..."
            rows={3}
            className="input-field w-full resize-none"
          />
        </Card>

        {saved && (
          <div className="text-center text-green-400 text-sm animate-pulse">Saved</div>
        )}
      </main>
    </div>
  );
}

function Card({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="card p-4 space-y-3">
      <div className="flex items-center gap-2 text-gray-300 font-medium">
        {icon}
        <span>{title}</span>
      </div>
      {children}
    </div>
  );
}
