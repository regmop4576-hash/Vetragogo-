export function uid(): string {
  return crypto.randomUUID();
}

export function stripHtml(md: string): string {
  return md.replace(/<[^>]*>/g, '');
}

export function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + '\u2026';
}
