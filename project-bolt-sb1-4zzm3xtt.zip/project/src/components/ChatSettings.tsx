import { X, Thermometer, Hash, Percent, Cpu, Pin } from 'lucide-react';
import type { Chat } from '../lib/types';
import type { AppSettings } from '../lib/types';
import { MODELS } from '../lib/types';

export default function ChatSettingsPanel({
  chat,
  settings,
  onUpdateChat,
  onUpdateSettings,
  onClose,
}: {
  chat: Chat;
  settings: AppSettings;
  onUpdateChat: (partial: Partial<Chat>) => void;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative ml-auto w-full max-w-sm bg-surface-0 border-l border-surface-2 overflow-y-auto">
        <div className="flex items-center justify-between px-4 h-14 border-b border-surface-2">
          <h2 className="font-semibold">Chat Settings</h2>
          <button onClick={onClose} className="btn-ghost"><X size={20} /></button>
        </div>

        <div className="p-4 space-y-5">
          <Section icon={<Pin size={16} />} title="Pinned Memory">
            <textarea
              value={chat.pinnedMemory}
              onChange={e => onUpdateChat({ pinnedMemory: e.target.value })}
              placeholder="Text always included in context..."
              rows={3}
              className="input-field w-full resize-none text-sm"
            />
          </Section>

          <Section icon={<Cpu size={16} />} title="Model Override">
            <select
              value={settings.model}
              onChange={e => onUpdateSettings({ model: e.target.value })}
              className="input-field w-full"
            >
              {MODELS.map(m => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </Section>

          <Section icon={<Thermometer size={16} />} title="Temperature">
            <Slider value={settings.temperature} min={0} max={2} step={0.05}
              onChange={v => onUpdateSettings({ temperature: v })} />
          </Section>

          <Section icon={<Hash size={16} />} title="Max Tokens">
            <Slider value={settings.maxTokens} min={100} max={4096} step={64}
              onChange={v => onUpdateSettings({ maxTokens: Math.round(v) })} />
          </Section>

          <Section icon={<Percent size={16} />} title="Top-P">
            <Slider value={settings.topP} min={0} max={1} step={0.05}
              onChange={v => onUpdateSettings({ topP: v })} />
          </Section>
        </div>
      </div>
    </div>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-sm font-medium text-gray-400">{icon}{title}</div>
      {children}
    </div>
  );
}

function Slider({ value, min, max, step, onChange }: {
  value: number; min: number; max: number; step: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="flex-1 accent-blue-500"
      />
      <span className="text-sm text-gray-400 w-12 text-right">
        {Number.isInteger(step) ? value : value.toFixed(2)}
      </span>
    </div>
  );
}
