import { useState, useEffect } from 'react';
import { ArrowLeft, Save, Plus, X } from 'lucide-react';
import { getCharacter, saveCharacter } from '../lib/db';
import type { Character } from '../lib/types';
import { uid } from '../lib/utils';

const EMPTY: Character = {
  id: '',
  name: '',
  avatar: '',
  description: '',
  personality: '',
  systemPrompt: '',
  exampleMessages: '',
  firstMessage: '',
  tags: [],
  createdAt: 0,
  updatedAt: 0,
};

export default function CharacterEditor({
  characterId,
  onSave,
}: {
  characterId: string | null;
  onSave: (id: string) => void;
}) {
  const [c, setC] = useState<Character>({ ...EMPTY, id: uid() });
  const [tagInput, setTagInput] = useState('');

  useEffect(() => {
    if (characterId) {
      getCharacter(characterId).then(ch => {
        if (ch) setC(ch);
      });
    }
  }, [characterId]);

  const set = (partial: Partial<Character>) => {
    setC(prev => ({ ...prev, ...partial, updatedAt: Date.now() }));
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !c.tags.includes(t)) {
      set({ tags: [...c.tags, t] });
    }
    setTagInput('');
  };

  const removeTag = (tag: string) => {
    set({ tags: c.tags.filter(t => t !== tag) });
  };

  const handleSave = async () => {
    if (!c.name.trim()) return;
    const now = Date.now();
    const ch: Character = {
      ...c,
      createdAt: c.createdAt || now,
      updatedAt: now,
    };
    await saveCharacter(ch);
    onSave(ch.id);
  };

  return (
    <div className="min-h-screen bg-surface-0">
      <header className="sticky top-0 z-10 bg-surface-0/80 backdrop-blur border-b border-surface-2">
        <div className="max-w-2xl mx-auto flex items-center justify-between px-4 h-14">
          <button onClick={() => onSave(c.id)} className="btn-ghost flex items-center gap-2">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-lg font-semibold">
            {characterId ? 'Edit Character' : 'Create Character'}
          </h1>
          <button
            onClick={handleSave}
            disabled={!c.name.trim()}
            className="btn-primary flex items-center gap-1.5 text-sm"
          >
            <Save size={16} />
            Save
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-5">
        {/* Avatar + Name */}
        <div className="flex gap-4 items-start">
          <div className="shrink-0">
            {c.avatar ? (
              <img src={c.avatar} alt="" className="w-20 h-20 rounded-xl object-cover border border-surface-2" />
            ) : (
              <div className="w-20 h-20 rounded-xl bg-surface-2 flex items-center justify-center text-2xl font-bold text-gray-500 border border-surface-3">
                {c.name ? c.name[0].toUpperCase() : '?'}
              </div>
            )}
          </div>
          <div className="flex-1 space-y-3">
            <input
              value={c.name}
              onChange={e => set({ name: e.target.value })}
              placeholder="Character name"
              className="input-field w-full text-lg"
            />
            <input
              value={c.avatar}
              onChange={e => set({ avatar: e.target.value })}
              placeholder="Avatar URL (https://...)"
              className="input-field w-full"
            />
          </div>
        </div>

        <Field label="Description">
          <textarea
            value={c.description}
            onChange={e => set({ description: e.target.value })}
            placeholder="Brief description of the character..."
            rows={3}
            className="input-field w-full resize-none"
          />
        </Field>

        <Field label="Personality">
          <textarea
            value={c.personality}
            onChange={e => set({ personality: e.target.value })}
            placeholder="Personality traits, mannerisms, speech style..."
            rows={3}
            className="input-field w-full resize-none"
          />
        </Field>

        <Field label="System Prompt">
          <textarea
            value={c.systemPrompt}
            onChange={e => set({ systemPrompt: e.target.value })}
            placeholder="System message that shapes AI behavior. E.g. 'You are a medieval knight who speaks formally...'"
            rows={5}
            className="input-field w-full resize-none font-mono text-sm"
          />
        </Field>

        <Field label="Example Messages">
          <textarea
            value={c.exampleMessages}
            onChange={e => set({ exampleMessages: e.target.value })}
            placeholder={"<START>\n{{user}}: Hello!\n{{char}}: *bows* Greetings, traveler."}
            rows={5}
            className="input-field w-full resize-none font-mono text-sm"
          />
        </Field>

        <Field label="First Message / Greeting">
          <textarea
            value={c.firstMessage}
            onChange={e => set({ firstMessage: e.target.value })}
            placeholder="*smiles warmly* Hello there! I've been waiting for you..."
            rows={4}
            className="input-field w-full resize-none"
          />
        </Field>

        <Field label="Tags">
          <div className="flex gap-2">
            <input
              value={tagInput}
              onChange={e => setTagInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addTag())}
              placeholder="Add tag..."
              className="input-field flex-1"
            />
            <button onClick={addTag} className="btn-ghost border border-surface-2">
              <Plus size={18} />
            </button>
          </div>
          {c.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {c.tags.map(tag => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-surface-2 text-sm text-gray-300"
                >
                  {tag}
                  <button onClick={() => removeTag(tag)} className="text-gray-500 hover:text-gray-300">
                    <X size={14} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </Field>
      </main>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="card p-4 space-y-2">
      <label className="text-sm font-medium text-gray-400">{label}</label>
      {children}
    </div>
  );
}
