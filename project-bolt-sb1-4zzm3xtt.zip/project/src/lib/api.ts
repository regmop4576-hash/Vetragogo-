import type { AppSettings } from './types';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function sendToOpenRouter(
  messages: ChatMessage[],
  settings: AppSettings,
  abortSignal?: AbortSignal,
): Promise<string> {
  const body: Record<string, unknown> = {
    model: settings.model,
    messages,
    temperature: settings.temperature,
    max_tokens: settings.maxTokens,
    top_p: settings.topP,
  };

  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${settings.apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': window.location.href,
    },
    body: JSON.stringify(body),
    signal: abortSignal,
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`API error ${res.status}: ${err}`);
  }

  const data = await res.json();
  if (data.error) {
    throw new Error(data.error.message || 'Unknown API error');
  }
  return data.choices?.[0]?.message?.content ?? '';
}
