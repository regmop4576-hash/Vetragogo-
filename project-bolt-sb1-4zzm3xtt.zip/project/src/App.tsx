import { useState, useCallback } from 'react';
import Home from './pages/Home';
import Chat from './pages/Chat';
import CharacterEditor from './pages/CharacterEditor';
import Settings from './pages/Settings';

type View =
  | { page: 'home' }
  | { page: 'chat'; chatId: string }
  | { page: 'editor'; characterId: string | null }
  | { page: 'settings' };

export default function App() {
  const [view, setView] = useState<View>({ page: 'home' });

  const goHome = useCallback(() => setView({ page: 'home' }), []);

  switch (view.page) {
    case 'home':
      return (
        <Home
          onOpenChat={chatId => setView({ page: 'chat', chatId })}
          onEditCharacter={id => setView({ page: 'editor', characterId: id })}
          onCreateCharacter={() => setView({ page: 'editor', characterId: null })}
          onSettings={() => setView({ page: 'settings' })}
        />
      );
    case 'chat':
      return <Chat chatId={view.chatId} onBack={goHome} />;
    case 'editor':
      return (
        <CharacterEditor
          characterId={view.characterId}
          onSave={() => setView({ page: 'home' })}
        />
      );
    case 'settings':
      return <Settings onBack={goHome} />;
  }
}
