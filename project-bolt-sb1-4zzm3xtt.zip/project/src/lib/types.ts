export interface Character {
  id: string;
  name: string;
  avatar: string;
  description: string;
  personality: string;
  systemPrompt: string;
  exampleMessages: string;
  firstMessage: string;
  tags: string[];
  createdAt: number;
  updatedAt: number;
}

export interface Message {
  id: string;
  chatId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  swipeIndex: number;
  swipeContents: string[];
  createdAt: number;
}

export interface Chat {
  id: string;
  characterId: string;
  title: string;
  pinnedMemory: string;
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  apiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
  topP: number;
  contextLength: number;
  jailbreakPrompt: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  apiKey: '',
  model: 'google/gemini-2.5-flash',
  temperature: 0.8,
  maxTokens: 1024,
  topP: 0.9,
  contextLength: 20,
  jailbreakPrompt: '',
};

export const MODELS = [
  { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
  { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet 4' },
  { id: 'openai/gpt-4o', name: 'GPT-4o' },
  { id: 'meta-llama/llama-4-maverick', name: 'Llama 4 Maverick' },
  { id: 'deepseek/deepseek-chat', name: 'DeepSeek V3' },
  { id: 'mistralai/mistral-large', name: 'Mistral Large' },
  { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro' },
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini' },
  { id: 'meta-llama/llama-3.3-70b-instruct', name: 'Llama 3.3 70B' },
  { id: 'qwen/qwen3-235b-a22b', name: 'Qwen3 235B' },
];
