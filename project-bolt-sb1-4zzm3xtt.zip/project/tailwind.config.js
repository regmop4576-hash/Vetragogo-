/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        surface: {
          0: '#1e1e2e',
          1: '#2a2a3e',
          2: '#3b3b54',
          3: '#4a4a64',
        },
      },
    },
  },
  plugins: [],
};
