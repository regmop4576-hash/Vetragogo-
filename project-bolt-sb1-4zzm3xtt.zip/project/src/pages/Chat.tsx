import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Settings, Square, X, Check } from 'lucide-react';
import { getChat, getCharacter, getMessagesByChat, saveMessage, deleteMessage, saveChat, getSettings, saveSettings } from '../lib/db';
import { sendToOpenRouter } from '../lib/api';
import { uid } from '../lib/utils';
import type { Chat as ChatType, Character, Message, AppSettings } from '../lib/types';
import { DEFAULT_SETTINGS } from '../lib/types';
import MessageBubble from '../components/MessageBubble';
import ChatSettingsPanel from '../components/ChatSettings';

export default function ChatPage({ chatId, onBack }: { chatId: string; onBack: () => void }) {
  const [chat, setChat] = useState<ChatType | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    load();
  }, [chatId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  async function load() {
    const c = await getChat(chatId);
    if (!c) return;
    setChat(c);
    const ch = await getCharacter(c.characterId);
    setCharacter(ch ?? null);
    const msgs = await getMessagesByChat(chatId);
    setMessages(msgs);
    const s = await getSettings();
    setSettings(s);
  }

  function scrollToBottom() {
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
  }

  async function handleSend() {
    const text = input.trim();
    if (!text || loading || !chat || !character) return;
    setInput('');
    setError(null);

    const userMsg: Message = {
      id: uid(),
      chatId: chat.id,
      role: 'user',
      content: text,
      swipeIndex: 0,
      swipeContents: [text],
      createdAt: Date.now(),
    };
    await saveMessage(userMsg);
    setMessages(prev => [...prev, userMsg]);

    await generateResponse([...messages, userMsg]);
  }

  async function generateResponse(contextMsgs: Message[]) {
    if (!chat || !character) return;
    setLoading(true);

    try {
      const apiMessages = buildApiMessages(contextMsgs, character, chat);
      const controller = new AbortController();
      abortRef.current = controller;

      const content = await sendToOpenRouter(apiMessages, settings, controller.signal);
      abortRef.current = null;

      const botMsg: Message = {
        id: uid(),
        chatId: chat.id,
        role: 'assistant',
        content,
        swipeIndex: 0,
        swipeContents: [content],
        createdAt: Date.now(),
      };
      await saveMessage(botMsg);
      setMessages(prev => [...prev, botMsg]);

      const now = Date.now();
      const updated = { ...chat, updatedAt: now };
      setChat(updated);
      await saveChat(updated);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'Failed to get response');
      }
    } finally {
      setLoading(false);
      abortRef.current = null;
    }
  }

  function buildApiMessages(
    contextMsgs: Message[],
    char: Character,
    chat: ChatType,
  ): { role: 'system' | 'user' | 'assistant'; content: string }[] {
    const systemParts: string[] = [];
    if (char.systemPrompt) systemParts.push(char.systemPrompt);
    if (chat.pinnedMemory) systemParts.push(`[Pinned Memory]\n${chat.pinnedMemory}`);
    if (settings.jailbreakPrompt) systemParts.push(settings.jailbreakPrompt);

    const system: { role: 'system' | 'user' | 'assistant'; content: string } = {
      role: 'system',
      content: systemParts.join('\n\n') || 'You are a helpful assistant.',
    };

    const recent = contextMsgs.slice(-settings.contextLength);
    const history = recent.map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    }));

    return [system, ...history];
  }

  function handleStop() {
    abortRef.current?.abort();
  }

  async function handleEdit(id: string) {
    const msg = messages.find(m => m.id === id);
    if (!msg) return;
    setEditingId(id);
    setEditContent(msg.content);
  }

  async function handleEditSave() {
    if (!editingId) return;
    const msg = messages.find(m => m.id === editingId);
    if (!msg) return;

    const updated: Message = {
      ...msg,
      content: editContent,
      swipeContents: msg.swipeContents.map((c, i) =>
        i === msg.swipeIndex ? editContent : c
      ),
    };
    await saveMessage(updated);
    setMessages(prev => prev.map(m => m.id === editingId ? updated : m));
    setEditingId(null);
    setEditContent('');
  }

  async function handleDelete(id: string) {
    await deleteMessage(id);
    setMessages(prev => prev.filter(m => m.id !== id));
  }

  async function handleRegenerate(id: string) {
    const msg = messages.find(m => m.id === id);
    if (!msg || loading || !chat || !character) return;

    await deleteMessage(id);
    const prevMsgs = messages.filter(m => m.id !== id);
    setMessages(prevMsgs);

    const contextForApi = [...prevMsgs];
    await generateResponse(contextForApi);
  }

  async function handleSwipe(id: string, dir: 1 | -1) {
    const msg = messages.find(m => m.id === id);
    if (!msg) return;

    const newIndex = msg.swipeIndex + dir;
    if (newIndex < 0 || newIndex >= msg.swipeContents.length) return;

    const updated: Message = {
      ...msg,
      swipeIndex: newIndex,
      content: msg.swipeContents[newIndex],
    };
    await saveMessage(updated);
    setMessages(prev => prev.map(m => m.id === id ? updated : m));
  }

  function handleUpdateChat(partial: Partial<ChatType>) {
    if (!chat) return;
    const updated = { ...chat, ...partial };
    setChat(updated);
    saveChat(updated);
  }

  function handleUpdateSettings(partial: Partial<AppSettings>) {
    const updated = { ...settings, ...partial };
    setSettings(updated);
    saveSettings(updated);
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!chat || !character) {
    return (
      <div className="min-h-screen bg-surface-0 flex items-center justify-center text-gray-500">
        Loading...
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-surface-0">
      {/* Header */}
      <header className="shrink-0 bg-surface-0/80 backdrop-blur border-b border-surface-2 z-10">
        <div className="flex items-center gap-3 px-4 h-14">
          <button onClick={onBack} className="btn-ghost">
            <ArrowLeft size={20} />
          </button>
          {character.avatar ? (
            <img src={character.avatar} alt="" className="w-8 h-8 rounded-lg object-cover" />
          ) : (
            <div className="w-8 h-8 rounded-lg bg-surface-2 flex items-center justify-center text-sm font-bold text-gray-500">
              {character.name[0].toUpperCase()}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h1 className="font-semibold truncate">{character.name}</h1>
          </div>
          <button onClick={() => setShowSettings(true)} className="btn-ghost">
            <Settings size={20} />
          </button>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        {messages.map(msg => (
          editingId === msg.id ? (
            <div key={msg.id} className="px-4 py-3 bg-surface-1/30">
              <div className="flex gap-2 items-start">
                <textarea
                  value={editContent}
                  onChange={e => setEditContent(e.target.value)}
                  className="input-field flex-1 resize-none min-h-[60px]"
                  autoFocus
                />
                <button onClick={handleEditSave} className="btn-primary p-2">
                  <Check size={16} />
                </button>
                <button onClick={() => setEditingId(null)} className="btn-ghost p-2">
                  <X size={16} />
                </button>
              </div>
            </div>
          ) : (
            <MessageBubble
              key={msg.id}
              msg={msg}
              avatar={character.avatar}
              name={character.name}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onRegenerate={handleRegenerate}
              onSwipe={handleSwipe}
            />
          )
        ))}

        {loading && (
          <div className="flex gap-3 px-4 py-3">
            <div className="shrink-0 pt-0.5">
              {character.avatar ? (
                <img src={character.avatar} alt="" className="w-9 h-9 rounded-lg object-cover" />
              ) : (
                <div className="w-9 h-9 rounded-lg bg-surface-2 flex items-center justify-center text-sm font-bold text-gray-500">
                  {character.name[0].toUpperCase()}
                </div>
              )}
            </div>
            <div className="flex items-center gap-1 pt-2">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
            </div>
          </div>
        )}

        {error && (
          <div className="mx-4 my-2 p-3 rounded-lg bg-red-900/20 border border-red-800/30 text-red-400 text-sm">
            {error}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="shrink-0 border-t border-surface-2 bg-surface-0 p-3">
        <div className="flex gap-2 items-end max-w-4xl mx-auto">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message..."
            rows={1}
            className="input-field flex-1 resize-none max-h-32"
            style={{ minHeight: '42px' }}
            onInput={e => {
              const t = e.target as HTMLTextAreaElement;
              t.style.height = 'auto';
              t.style.height = Math.min(t.scrollHeight, 128) + 'px';
            }}
          />
          {loading ? (
            <button onClick={handleStop} className="bg-red-600 hover:bg-red-500 text-white p-2.5 rounded-lg transition-colors">
              <Square size={18} />
            </button>
          ) : (
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="btn-primary p-2.5 disabled:opacity-30"
            >
              <Send size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Settings panel */}
      {showSettings && (
        <ChatSettingsPanel
          chat={chat}
          settings={settings}
          onUpdateChat={handleUpdateChat}
          onUpdateSettings={handleUpdateSettings}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}
