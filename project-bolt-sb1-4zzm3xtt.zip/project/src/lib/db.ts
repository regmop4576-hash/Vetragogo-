import { openDB, type IDBPDatabase } from 'idb';
import type { Character, Chat, Message, AppSettings } from './types';
import { DEFAULT_SETTINGS } from './types';

const DB_NAME = 'rolechat';
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('characters')) {
          db.createObjectStore('characters', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('chats')) {
          const chatStore = db.createObjectStore('chats', { keyPath: 'id' });
          chatStore.createIndex('characterId', 'characterId');
        }
        if (!db.objectStoreNames.contains('messages')) {
          const msgStore = db.createObjectStore('messages', { keyPath: 'id' });
          msgStore.createIndex('chatId', 'chatId');
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      },
    });
  }
  return dbPromise;
}

// Characters
export async function getAllCharacters(): Promise<Character[]> {
  const db = await getDB();
  return db.getAll('characters');
}

export async function getCharacter(id: string): Promise<Character | undefined> {
  const db = await getDB();
  return db.get('characters', id);
}

export async function saveCharacter(character: Character): Promise<void> {
  const db = await getDB();
  await db.put('characters', character);
}

export async function deleteCharacter(id: string): Promise<void> {
  const db = await getDB();
  const chats = await getChatsByCharacter(id);
  for (const chat of chats) {
    await deleteChat(chat.id);
  }
  await db.delete('characters', id);
}

// Chats
export async function getAllChats(): Promise<Chat[]> {
  const db = await getDB();
  return db.getAll('chats');
}

export async function getChatsByCharacter(characterId: string): Promise<Chat[]> {
  const db = await getDB();
  return db.getAllFromIndex('chats', 'characterId', characterId);
}

export async function getChat(id: string): Promise<Chat | undefined> {
  const db = await getDB();
  return db.get('chats', id);
}

export async function saveChat(chat: Chat): Promise<void> {
  const db = await getDB();
  await db.put('chats', chat);
}

export async function deleteChat(id: string): Promise<void> {
  const db = await getDB();
  const msgs = await getMessagesByChat(id);
  const tx = db.transaction(['chats', 'messages'], 'readwrite');
  for (const msg of msgs) {
    await tx.objectStore('messages').delete(msg.id);
  }
  await tx.objectStore('chats').delete(id);
  await tx.done;
}

// Messages
export async function getMessagesByChat(chatId: string): Promise<Message[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex('messages', 'chatId', chatId);
  return all.sort((a, b) => a.createdAt - b.createdAt);
}

export async function saveMessage(message: Message): Promise<void> {
  const db = await getDB();
  await db.put('messages', message);
}

export async function deleteMessage(id: string): Promise<void> {
  const db = await getDB();
  await db.delete('messages', id);
}

// Settings
export async function getSettings(): Promise<AppSettings> {
  const db = await getDB();
  const rows = await db.getAll('settings');
  const map: Record<string, string> = {};
  for (const row of rows) {
    map[row.key] = row.value;
  }
  return {
    apiKey: map.apiKey ?? DEFAULT_SETTINGS.apiKey,
    model: map.model ?? DEFAULT_SETTINGS.model,
    temperature: map.temperature ? parseFloat(map.temperature) : DEFAULT_SETTINGS.temperature,
    maxTokens: map.maxTokens ? parseInt(map.maxTokens) : DEFAULT_SETTINGS.maxTokens,
    topP: map.topP ? parseFloat(map.topP) : DEFAULT_SETTINGS.topP,
    contextLength: map.contextLength ? parseInt(map.contextLength) : DEFAULT_SETTINGS.contextLength,
    jailbreakPrompt: map.jailbreakPrompt ?? DEFAULT_SETTINGS.jailbreakPrompt,
  };
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  const db = await getDB();
  const tx = db.transaction('settings', 'readwrite');
  const store = tx.objectStore('settings');
  await store.put({ key: 'apiKey', value: settings.apiKey });
  await store.put({ key: 'model', value: settings.model });
  await store.put({ key: 'temperature', value: String(settings.temperature) });
  await store.put({ key: 'maxTokens', value: String(settings.maxTokens) });
  await store.put({ key: 'topP', value: String(settings.topP) });
  await store.put({ key: 'contextLength', value: String(settings.contextLength) });
  await store.put({ key: 'jailbreakPrompt', value: settings.jailbreakPrompt });
  await tx.done;
}
