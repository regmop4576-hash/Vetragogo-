import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Pencil, Trash2, RefreshCw, ChevronLeft, ChevronRight, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import type { Message } from '../lib/types';

export default function MessageBubble({
  msg,
  avatar,
  name,
  onEdit,
  onDelete,
  onRegenerate,
  onSwipe,
}: {
  msg: Message;
  avatar: string;
  name: string;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onRegenerate: (id: string) => void;
  onSwipe: (id: string, dir: 1 | -1) => void;
}) {
  const [hover, setHover] = useState(false);
  const [copied, setCopied] = useState(false);
  const isBot = msg.role === 'assistant';

  const handleCopy = () => {
    navigator.clipboard.writeText(msg.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      className={`group flex gap-3 px-4 py-3 transition-colors ${isBot ? 'hover:bg-white/[0.02]' : 'flex-row-reverse'}`}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {/* Avatar */}
      <div className="shrink-0 pt-0.5">
        {isBot ? (
          avatar ? (
            <img src={avatar} alt="" className="w-9 h-9 rounded-lg object-cover" />
          ) : (
            <div className="w-9 h-9 rounded-lg bg-surface-2 flex items-center justify-center text-sm font-bold text-gray-500">
              {name[0].toUpperCase()}
            </div>
          )
        ) : (
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-sm font-bold">
            U
          </div>
        )}
      </div>

      {/* Content */}
      <div className={`flex-1 min-w-0 ${isBot ? '' : 'text-right'}`}>
        <div className="flex items-center gap-2 mb-1">
          <span className={`text-xs font-medium ${isBot ? 'text-gray-400' : 'text-blue-400'}`}>
            {isBot ? name : 'You'}
          </span>
          {isBot && msg.swipeContents.length > 1 && (
            <span className="text-xs text-gray-600">
              {msg.swipeIndex + 1}/{msg.swipeContents.length}
            </span>
          )}
        </div>
        <div className={`msg-content text-gray-200 leading-relaxed ${isBot ? '' : 'inline-block text-left'}`}>
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {msg.content}
          </ReactMarkdown>
        </div>

        {/* Actions */}
        {hover && (
          <div className={`flex items-center gap-1 mt-2 ${isBot ? '' : 'justify-end'}`}>
            <button onClick={handleCopy} className="msg-action" title="Copy">
              {copied ? <Check size={14} /> : <Copy size={14} />}
            </button>
            <button onClick={() => onEdit(msg.id)} className="msg-action" title="Edit">
              <Pencil size={14} />
            </button>
            <button onClick={() => onDelete(msg.id)} className="msg-action" title="Delete">
              <Trash2 size={14} />
            </button>
            {isBot && (
              <button onClick={() => onRegenerate(msg.id)} className="msg-action" title="Regenerate">
                <RefreshCw size={14} />
              </button>
            )}
            {isBot && msg.swipeContents.length > 0 && (
              <>
                <button
                  onClick={() => onSwipe(msg.id, -1)}
                  className="msg-action"
                  disabled={msg.swipeIndex <= 0}
                  title="Previous swipe"
                >
                  <ChevronLeft size={14} />
                </button>
                <button
                  onClick={() => onSwipe(msg.id, 1)}
                  className="msg-action"
                  disabled={msg.swipeIndex >= msg.swipeContents.length - 1}
                  title="Next swipe"
                >
                  <ChevronRight size={14} />
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
