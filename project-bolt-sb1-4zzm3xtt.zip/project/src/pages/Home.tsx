import { useState, useEffect } from 'react';
import { Plus, Settings, MessageCircle, Trash2, Pencil } from 'lucide-react';
import { getAllCharacters, deleteCharacter, getChatsByCharacter, saveChat, saveMessage } from '../lib/db';
import type { Character, Chat } from '../lib/types';
import { uid } from '../lib/utils';

export default function Home({
  onOpenChat,
  onEditCharacter,
  onCreateCharacter,
  onSettings,
}: {
  onOpenChat: (chatId: string) => void;
  onEditCharacter: (id: string) => void;
  onCreateCharacter: () => void;
  onSettings: () => void;
}) {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [chatMap, setChatMap] = useState<Record<string, Chat[]>>({});
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const chars = await getAllCharacters();
    setCharacters(chars.sort((a, b) => b.updatedAt - a.updatedAt));
    const map: Record<string, Chat[]> = {};
    for (const ch of chars) {
      map[ch.id] = await getChatsByCharacter(ch.id);
    }
    setChatMap(map);
  }

  async function handleDeleteCharacter(id: string) {
    await deleteCharacter(id);
    setMenuOpen(null);
    load();
  }

  async function startChat(character: Character) {
    const existing = chatMap[character.id];
    if (existing && existing.length > 0) {
      onOpenChat(existing[0].id);
      return;
    }
    const chatId = uid();
    const now = Date.now();
    const chat: Chat = {
      id: chatId,
      characterId: character.id,
      title: character.name,
      pinnedMemory: '',
      createdAt: now,
      updatedAt: now,
    };
    await saveChat(chat);

    if (character.firstMessage) {
      await saveMessage({
        id: uid(),
        chatId,
        role: 'assistant',
        content: character.firstMessage,
        swipeIndex: 0,
        swipeContents: [character.firstMessage],
        createdAt: now + 1,
      });
    }

    onOpenChat(chatId);
  }

  return (
    <div className="min-h-screen bg-surface-0">
      <header className="sticky top-0 z-10 bg-surface-0/80 backdrop-blur border-b border-surface-2">
        <div className="max-w-4xl mx-auto flex items-center justify-between px-4 h-14">
          <h1 className="text-xl font-bold tracking-tight">
            <span className="text-blue-400">Role</span>Chat
          </h1>
          <div className="flex items-center gap-2">
            <button onClick={onSettings} className="btn-ghost">
              <Settings size={20} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        {characters.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-20 h-20 rounded-2xl bg-surface-1 flex items-center justify-center mb-4">
              <MessageCircle size={36} className="text-gray-500" />
            </div>
            <h2 className="text-xl font-semibold text-gray-300 mb-2">No characters yet</h2>
            <p className="text-gray-500 mb-6 max-w-sm">
              Create your first AI character to start roleplaying
            </p>
            <button onClick={onCreateCharacter} className="btn-primary flex items-center gap-2">
              <Plus size={18} />
              Create Character
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {characters.map(ch => (
              <div
                key={ch.id}
                className="card hover:border-surface-3 transition-colors group cursor-pointer relative"
                onClick={() => startChat(ch)}
              >
                <div className="p-4">
                  <div className="flex items-start gap-3">
                    {ch.avatar ? (
                      <img src={ch.avatar} alt="" className="w-12 h-12 rounded-lg object-cover shrink-0" />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-surface-2 flex items-center justify-center text-lg font-bold text-gray-500 shrink-0">
                        {ch.name[0].toUpperCase()}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-100 truncate">{ch.name}</h3>
                      <p className="text-sm text-gray-500 line-clamp-2 mt-0.5">
                        {ch.description || ch.personality || 'No description'}
                      </p>
                    </div>
                  </div>
                  {ch.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {ch.tags.slice(0, 4).map(tag => (
                        <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-surface-2 text-gray-400">
                          {tag}
                        </span>
                      ))}
                      {ch.tags.length > 4 && (
                        <span className="text-xs text-gray-500">+{ch.tags.length - 4}</span>
                      )}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 mt-3">
                    <MessageCircle size={14} className="text-gray-500" />
                    <span className="text-xs text-gray-500">
                      {(chatMap[ch.id]?.length ?? 0)} chat{(chatMap[ch.id]?.length ?? 0) !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>

                {/* Context menu */}
                <div className="absolute top-2 right-2">
                  <button
                    onClick={e => { e.stopPropagation(); setMenuOpen(menuOpen === ch.id ? null : ch.id); }}
                    className="p-1.5 rounded-lg hover:bg-white/5 text-gray-500 hover:text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                      <circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/>
                    </svg>
                  </button>
                  {menuOpen === ch.id && (
                    <div className="absolute right-0 top-8 bg-surface-1 border border-surface-2 rounded-lg shadow-xl py-1 z-20 min-w-[140px]">
                      <button
                        onClick={e => { e.stopPropagation(); setMenuOpen(null); onEditCharacter(ch.id); }}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-white/5 flex items-center gap-2 text-gray-300"
                      >
                        <Pencil size={14} /> Edit
                      </button>
                      <button
                        onClick={e => { e.stopPropagation(); handleDeleteCharacter(ch.id); }}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-white/5 flex items-center gap-2 text-red-400"
                      >
                        <Trash2 size={14} /> Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}

            <button
              onClick={onCreateCharacter}
              className="card hover:border-blue-500/30 transition-colors flex flex-col items-center justify-center py-10 gap-2 text-gray-500 hover:text-blue-400"
            >
              <Plus size={28} />
              <span className="text-sm font-medium">New Character</span>
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
